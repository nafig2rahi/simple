<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\local as Authenticatable;

class local extends Model
{

}