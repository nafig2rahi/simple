<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

use Illuminate\Http\Request;
use App\local;
class HomeController extends Controller
{
    public function register(){
        return view('reg.register');
    }
    public function logged(){
    	return view('reg.log');
    } 
    public function postlogin(Request $request){
    	$email = $request->email;
    	$password =$request->password;
    	$obj =local::where('email','=',$email)
    				->where('password','=',$password)
    				->first();

    if($obj){
    	echo 'Successfully';
    	Session::put('userid',$obj->id);
        //return view('reg.dashboard');
    }
    else{
        echo 'log in unsuccessfull';

    }
    }

     public function dashboard(){
            return view('reg.dashboard');
       }
   public function users(){
            return view('reg.users');
       }
    public function logout(Request $request){
  	$request->Session()->flush();
    return redirect('/log');
  
    }
}
